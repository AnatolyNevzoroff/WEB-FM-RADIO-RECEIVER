# BD37534FV
BD37534FV - Sound Processor with Built-in 3-band Equalizer
Alexander Liman 
liman324@yandex.ru
Скетч BD37534FV + энкодер + ИК пульт + LCD1602 http://forum.rcl-radio.ru/viewtopic.php?id=50
