var group___g_a01_structrda__reg00_8refined =
[
    [ "CHIPID", "group___g_a01.html#aac492b91a84a26e0d5b03df920b988ee", null ],
    [ "DUMMY", "group___g_a01.html#abd2103035a8021942390a78a431ba0c4", null ]
];