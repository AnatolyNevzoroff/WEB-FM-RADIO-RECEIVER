var group___g_a01_structrda__reg0d_8refined =
[
    [ "lowByte", "group___g_a01.html#a51ab88497cad20027df936afa223b23d", null ],
    [ "highByte", "group___g_a01.html#a7b99e4a5dc723242645ede8c604610df", null ]
];