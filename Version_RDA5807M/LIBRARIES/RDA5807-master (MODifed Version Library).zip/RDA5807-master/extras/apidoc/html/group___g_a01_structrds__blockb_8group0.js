var group___g_a01_structrds__blockb_8group0 =
[
    [ "address", "group___g_a01.html#a884d9804999fc47a3c2694e49ad2536a", null ],
    [ "DI", "group___g_a01.html#aa1b1c0cd777edd2e5cfcaf8e2e7dcab8", null ],
    [ "MS", "group___g_a01.html#a7a663caea1b722a63dc2868158ed584d", null ],
    [ "TA", "group___g_a01.html#a890a10788493e3d572586e991cd43543", null ],
    [ "programType", "group___g_a01.html#a264bd2c2ca8c895803767b0d39ff4a09", null ],
    [ "trafficProgramCode", "group___g_a01.html#a59e69d63ce38754ea53c4461b5cba1e2", null ],
    [ "versionCode", "group___g_a01.html#a20583dcf173525a78f726ef45329c5ae", null ],
    [ "groupType", "group___g_a01.html#a19223bd3731a4215ead3ba6a1eb8bbe8", null ]
];