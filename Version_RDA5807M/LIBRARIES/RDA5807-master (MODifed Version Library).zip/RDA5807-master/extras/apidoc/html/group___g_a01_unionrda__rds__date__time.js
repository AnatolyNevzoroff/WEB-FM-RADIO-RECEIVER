var group___g_a01_unionrda__rds__date__time =
[
    [ "refined", "group___g_a01.html#ae54ec79de07a1ab231ff2c29f1b4fc39", null ],
    [ "raw", "group___g_a01.html#a0f235f5ddf6fc8efbd88b3bdc6c8fd8c", null ]
];