var group___g_a01_unionrda__reg00 =
[
    [ "refined", "group___g_a01.html#ac5a1a7191e10e3c1d300537387e6acbc", null ],
    [ "raw", "group___g_a01.html#a4032484c615397b498d1af01aa1d1453", null ]
];