var group___g_a01_unionrda__reg07 =
[
    [ "refined", "group___g_a01.html#ac5c4daceecb405708b96c79b477db70b", null ],
    [ "raw", "group___g_a01.html#a2dacd798a51d8fc4effa015d9d16c1a0", null ]
];