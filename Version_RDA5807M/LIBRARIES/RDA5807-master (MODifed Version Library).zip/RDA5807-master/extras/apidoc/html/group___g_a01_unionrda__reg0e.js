var group___g_a01_unionrda__reg0e =
[
    [ "refined", "group___g_a01.html#a63c425b6b07f0604a43481f0312d3d59", null ],
    [ "RDSC", "group___g_a01.html#a519e4146ff314e51a19f354ec7f07b8e", null ]
];