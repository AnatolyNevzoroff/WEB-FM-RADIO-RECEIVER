var group___g_a01_unionrda__reg0f =
[
    [ "refined", "group___g_a01.html#a2277c8c28e92e2ad993af1c0c5fb4c94", null ],
    [ "RDSD", "group___g_a01.html#a468a600809a23e18a9b40dadccfd3740", null ]
];