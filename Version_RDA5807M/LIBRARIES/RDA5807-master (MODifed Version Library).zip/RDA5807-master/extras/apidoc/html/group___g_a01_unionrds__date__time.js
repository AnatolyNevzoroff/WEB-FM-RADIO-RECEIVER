var group___g_a01_unionrds__date__time =
[
    [ "refined", "group___g_a01.html#a9bcded0e419c611d9920953260c352cb", null ],
    [ "raw", "group___g_a01.html#abb6c459455299730ef24dc149a871202", null ]
];