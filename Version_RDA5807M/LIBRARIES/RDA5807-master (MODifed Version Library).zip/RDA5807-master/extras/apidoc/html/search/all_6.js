var searchData=
[
  ['max_5fdelay_5fafter_5foscillator_49',['MAX_DELAY_AFTER_OSCILLATOR',['../_r_d_a5807_8h.html#afb81dd661d531fa5c5422549fab7588f',1,'RDA5807.h']]],
  ['maxdelayaftarcrystalon_50',['maxDelayAftarCrystalOn',['../group___g_a01.html#a8b9e02f7c7121cf57fc0006f4ff7162a',1,'RDA5807']]]
];
