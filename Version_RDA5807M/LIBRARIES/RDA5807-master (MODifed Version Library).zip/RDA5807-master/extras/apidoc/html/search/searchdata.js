var indexSectionsWithContent =
{
  0: "bcdghimoprstuw",
  1: "rw",
  2: "r",
  3: "cghipsw",
  4: "bcdgmor",
  5: "cimors",
  6: "bru",
  7: "rt"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables",
  5: "defines",
  6: "groups",
  7: "pages"
};

var indexSectionLabels =
{
  0: "All",
  1: "Data Structures",
  2: "Files",
  3: "Functions",
  4: "Variables",
  5: "Macros",
  6: "Modules",
  7: "Pages"
};

