var searchData=
[
  ['deviceaddressdirectaccess_264',['deviceAddressDirectAccess',['../group___g_a01.html#a18c3e5a103b683af7c46d8b9a3d47518',1,'RDA5807']]],
  ['deviceaddressfullaccess_265',['deviceAddressFullAccess',['../group___g_a01.html#a81c00f45187f93be0698ef8c5bd80619',1,'RDA5807']]]
];
